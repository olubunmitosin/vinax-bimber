<?php
/**
 * Lazy load YouTube module loader
 *
 * @package media-ace
 * @subpackage Functions
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'functions.php' );

if ( mace_get_lazy_load_embeds() ) {
	require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'youtube.php' );
}

if ( is_admin() ) {
	require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'admin/settings.php' );
}


