<?php
/**
 *  The template for displaying shares
 *
 * @license For the full license information, please view the Licensing folder
 * that was distributed with this source code.
 *
 * @package media-ace
 * @subpackage Templates
 */


// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

$fb_app_id = mace_get_fb_key();
$unique = uniqid();
if ( mace_gallery_is_facebook_enabled() ) :
?>
<script type="text/javascript">
			(function () {
				var triggerOnLoad = false;

				window.apiShareOnFB = function() {
					jQuery('body').trigger('snaxFbNotLoaded');
					triggerOnLoad = true;
				};

				var _fbAsyncInitGallery = window.fbAsyncInitGallery;

				window.fbAsyncInitGallery = function() {
					FB.init({
						appId      : '<?php echo esc_attr( $fb_app_id ); ?>',
						xfbml      : true,
						version    : 'v3.0'
					});
					window.apiShareOnFB_mace_replace_unique = function() {
						var shareTitle 		    = 'mace_replace_noesc_title';
						var shareDescription	= '';
						var shareImage	        = 'mace_replace_noesc_image_url';

						FB.login(function(response) {
							if (response.status === 'connected') {
								var objectToShare = {
									'og:url':           'mace_replace_noesc_shortlink', // Url to share.
									'og:title':         shareTitle,
									'og:description':   shareDescription
								};

								// Add image only if set. FB fails otherwise.
								if (shareImage) {
									objectToShare['og:image'] = shareImage;
								}

								FB.ui({
										method: 'share_open_graph',
										action_type: 'og.shares',
										action_properties: JSON.stringify({
											object : objectToShare
										})
									},
									// callback
									function(response) {
									});
							}
						});
					};

					// Fire original callback.
					if (typeof _fbAsyncInitGallery === 'function') {
						_fbAsyncInitGallery();
					}

					// Open share popup as soon as possible, after loading FB SDK.`
					if (triggerOnLoad) {
						setTimeout(function() {
							apiShareOnFB();
						}, 1000);
					}
				};

				// JS SDK loaded before we hook into it. Trigger callback now.
				if (typeof window.FB !== 'undefined') {
					window.fbAsyncInitGallery();
				}
				jQuery('body').on('maceGalleryItemChanged', function(){
					window.fbAsyncInitGallery();
				});
			})();
		</script>

<?php
	$fb_onclick = 'apiShareOnFB_mace_replace_unique';
	printf(
		'<a class="g1-gallery-share g1-gallery-share-fb" href="#" title="%3s" onclick="%4s(); return false;" target="_blank" rel="nofollow">%5s</a>',
		esc_attr( __( 'Share on Facebook', 'mace' ) ),
		esc_attr( $fb_onclick ),
		esc_html( __( 'Share on Facebook', 'mace' ) )
	);
endif;
if ( mace_gallery_is_twitter_enabled() ) {
	$twitter_url = 'https://twitter.com/home?status=mace_replace_title%20mace_replace_shortlink';
	printf(
		'<a class="g1-gallery-share g1-gallery-share-twitter" href="%1s" title="%2s" target="_blank" rel="nofollow">%3s</a>',
		esc_url_raw( $twitter_url ),
		esc_attr( __( 'Share on Twitter', 'mace' ) ),
		esc_html( __( 'Share on Twitter', 'mace' ) )
	);
}
if ( mace_gallery_is_pinterest_enabled() ) {
	$pinterest_url = 'https://pinterest.com/pin/create/button/?url=mace_replace_shortlink&amp;description=mace_replace_title&amp;media=mace_replace_image_url';
	printf(
		'<a class="g1-gallery-share g1-gallery-share-pinterest" href="%1s" title="%2s" target="_blank" rel="nofollow">%3s</a>',
		esc_url_raw( $pinterest_url ),
		esc_attr( __( 'Share on Pinterest', 'mace' ) ),
		esc_html( __( 'Share on Pinterest', 'mace' ) )
	);
}
?>
