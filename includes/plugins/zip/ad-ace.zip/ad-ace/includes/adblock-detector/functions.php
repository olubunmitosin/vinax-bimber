<?php
/**
 * Common Functions
 *
 * @package AdAce.
 * @subpackage Functions
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

add_action( 'wp_enqueue_scripts', 'adace_adblock_enqueue_scripts' );
add_action( 'wp_footer', 'adace_adblock_detector_check' );

function adace_adblock_enqueue_scripts() {
	$detector = get_option( 'adace_adblock_detector_enabled', adace_options_get_defaults( 'adace_adblock_detector_enabled' ) );

	if ( 'standard' === $detector ) {
		wp_enqueue_script( 'adace-adijs', adace_get_plugin_url() . '/includes/adblock-detector/jquery.adi.js', array( 'jquery' ) );
		wp_enqueue_script( 'adace-adijs-pot', adace_get_plugin_url() . '/includes/adblock-detector/advertisement.js', array( 'adace-adijs' ) );
	}
}

function adace_adblock_detector_check() {
	$trigger_alert  = apply_filters( 'adace_adblock_trigger_alert', false );
	adace_get_template_part( 'adblock-detector' );
	$page 			= get_option( 'adace_adblock_detector_page', adace_options_get_defaults( 'adace_adblock_detector_page' ) );
	if ( '-1' !== $page && is_page( $page ) ) {
		return;
	}
	?>
	<script>
		(function ($) {
			"use strict";

			<?php if ( $trigger_alert ) : ?>
			var triggerAlert = true;
			<?php else: ?>
			var triggerAlert = false;
			<?php endif; ?>

			var adblockDetectedAlert = function() {
				$('html').addClass('adace-adi-popup-visible');
				$('.adace-adi-refresh-button').on('click', function(){
					window.location.reload();
				});
				$('.adace-adi-close').on('click', function(){
					console.log('e');
					$('html').removeClass('adace-adi-popup-visible');
				});
			};

			$(document).ready(function () {
				// Only when the AdBlocker is enabled this script will be available.
				if ( typeof $.adi === 'function' ) {
					$.adi({
						onOpen: function (el) {
							adblockDetectedAlert();
						}
					});
				}

				// Show alert on demand. AdBlocker can be disabled.
				if (triggerAlert) {
					adblockDetectedAlert();
				}
			});
		})(jQuery);
	</script>
	<?php
}
