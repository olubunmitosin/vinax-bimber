<?php
/**
 * Init Ads
 *
 * @package AdAce.
 * @subpackage Sponsors.
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}

// Load ads common parts.
require_once( trailingslashit( adace_get_plugin_dir() ) . 'includes/adblock-detector/functions.php' );

add_filter( 'adace_options_defaults', 'adace_options_add_adblock_detector_defaults' );

if ( is_admin() ) {
	require_once( trailingslashit( adace_get_plugin_dir() ) . 'includes/options-page-adblock-detector.php' );
}

require_once( trailingslashit( adace_get_plugin_dir() ) . 'includes/adblock-detector/functions.php' );

/**
 * Add Shop The Post Defaults.
 *
 * @param array $option_key Key to get default for.
 * @return mixed Default value or false.
 */
function adace_options_add_adblock_detector_defaults( $defaults ) {
	$defaults = array_merge( $defaults, array(
		'adace_adblock_detector_enabled' => 'none',
		'adace_adblock_detector_title' => 'Ad Blocker Detected!',
		'adace_adblock_detector_description' => 'Advertisements fund this website. Please disable your adblocking software or whitelist our website.<br>Thank You!',
		'adace_adblock_detector_page' => '-1',
	) );
	return $defaults;
}
