<?php
/**
 * Snax Shortcodes
 *
 * @package snax
 * @subpackage Shortcodes
 */

// Prevent direct script access.
if ( ! defined( 'ABSPATH' ) ) {
	die( 'No direct script access allowed' );
}
