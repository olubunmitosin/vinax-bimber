<?php
/**
 * Snax Content Template Part
 *
 * @package snax 1.11
 * @subpackage Theme
 */

?>

<div class="snax snax-post-container">
	<?php
        snax_amp_render_referral_link();
	?>
</div>
